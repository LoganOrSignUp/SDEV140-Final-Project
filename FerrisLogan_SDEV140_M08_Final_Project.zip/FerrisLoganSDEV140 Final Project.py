#import tkinter
from tkinter import *
#import regex
import re
#import image from PIL
from PIL import Image, ImageTk

#creates main menu window
root = Tk()
root.title("Main Menu")
root.geometry("860x670")

#background frame
background = Frame(root, width=600, height=400)
background.pack()
background.place(anchor="center", relx=0.5, rely=0.7)

#logo frame
logoFrame = Frame(root, width=250, height=250)
logoFrame.pack()
logoFrame.place(anchor="center", relx=0.5, rely=0.2)

# Creates images
Hamburger = ImageTk.PhotoImage(Image.open("Hamburger.png"))
Logo = ImageTk.PhotoImage(Image.open("Logo.png"))

# Create a labels for images
HamLabel = Label(background, image = Hamburger)
HamLabel.pack()
LogoLable = Label(logoFrame, image = Logo)
LogoLable.pack()

#def validate(userinput):
#    return userinput.replace.isdigit()
def validate(userinput):
    if re.match("\d*\.?\d*", userinput):
        return True
    else:
        return False

isvalid = root.register(validate)

###############################
#   Start Profit Calculator   #
###############################

#creates profit calculator
def OpenProfitCalculator():
    ProfitCalculator=Toplevel()
    ProfitCalculator.title("Profit Calculator")
    ProfitCalculator.geometry("250x175")
    
    #enable calculate button once forms are filled
    def isProfitFilled(ProfitFilled):
        if len(ItemCost.get()) < 1 or len(SellPrice.get()) < 1 or len(Sold.get()) < 1 or len(Wasted.get()) < 1:
            calcbutton.configure(state="disabled")
        else:
            calcbutton.configure(state="active")
    ProfitCalculator.bind("<KeyRelease>", isProfitFilled)
    
    #calculates profit from product
    def TotalProfit():
        result=(float(Sold.get())*(float(SellPrice.get())-float(ItemCost.get())))-(float(Wasted.get())*float(ItemCost.get()))
        output.set(result)
    
    #creating a string variable to store the result
    output=StringVar();

    #create frames
    firstframe = Frame(ProfitCalculator)
    firstframe.pack()

    secondframe = Frame(ProfitCalculator)
    secondframe.pack( side = BOTTOM )

    #Input cost
    Label(firstframe, text="Item Cost:").grid(row=0)
    ItemCost = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    ItemCost.grid(row=0, column=1)

    #Input sell price
    Label(firstframe, text="Sell Price:").grid(row=1)
    SellPrice = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    SellPrice.grid(row=1, column=1)

    #input amount sold
    Label(firstframe, text="Sold:").grid(row=2)
    Sold = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    Sold.grid(row=2, column=1)

    #input amount wasted
    Label(firstframe, text="Wasted:").grid(row=3)
    Wasted = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    Wasted.grid(row=3, column=1)

    #Result label and results
    Label(firstframe, text="Profit:").grid(row=5)
    Label(firstframe,text="",textvariable=output).grid(row=5,column=1)

    #Calculate button
    calcbutton = Button(secondframe, text ="Calcualte Profit", command=TotalProfit)
    calcbutton.pack()
    #exit button
    exitbutton = Button(secondframe, text ="Exit window", fg ="red", command=ProfitCalculator.destroy)
    exitbutton.pack()

    #disable calculation button until all forms are filled
    calcbutton.configure(state="disabled")
###############################
#    End Profit Calculator    #
###############################

###############################
#   Start Totals Calculator   #
###############################

#creates totals calculator
def OpenTotalsCalculator():
    TotalsCalculator=Toplevel()
    TotalsCalculator.title("Totals Calculator")
    TotalsCalculator.geometry("300x825")

    #enable add day button once forms are filled
    def isTotalsFilled(TotalsFilled):
        if len(SixAM.get()) < 1 or len(SevenAM.get()) < 1 or len(EightAM.get()) < 1 or len(NineAM.get()) < 1 or len(TenAM.get()) < 1 or len(ElevenAM.get()) < 1 or len(TwelvePM.get()) < 1 or len(OnePM.get()) < 1 or len(TwoPM.get()) < 1 or len(ThreePM.get()) < 1 or len(FourPM.get()) < 1 or  len(FivePM.get()) < 1 or len(SixPM.get()) < 1 or len(SevenPM.get()) < 1 or len(EightPM.get()) < 1 or len(NinePM.get()) < 1 or len(TenPM.get()) < 1 or len(ElevenPM.get()) < 1:
            addday.configure(state="disabled")
        else:
            addday.configure(state="active")
    TotalsCalculator.bind("<KeyRelease>", isTotalsFilled)

    #creates frames
    firstframe = Frame(TotalsCalculator)
    firstframe.pack()
    
    secondframe = Frame(TotalsCalculator)
    secondframe.pack( side = BOTTOM )

    #Make Strings for results
    MakeSixAM=StringVar();
    MakeSevenAM=StringVar();
    MakeEightAM=StringVar();
    MakeNineAM=StringVar();
    MakeTenAM=StringVar();
    MakeElevenAM=StringVar();
    MakeTwelvePM=StringVar();
    MakeOnePM=StringVar();
    MakeTwoPM=StringVar();
    MakeThreePM=StringVar();
    MakeFourPM=StringVar();
    MakeFivePM=StringVar();
    MakeSixPM=StringVar();
    MakeSevenPM=StringVar();
    MakeEightPM=StringVar();
    MakeNinePM=StringVar();
    MakeTenPM=StringVar();
    MakeElevenPM=StringVar();

    #Set value for loop
    i=0

    #create lists for calculations
    SixAMCalc=[]
    SevenAMCalc=[]
    EightAMCalc=[]
    NineAMCalc=[]
    TenAMCalc=[]
    ElevenAMCalc=[]
    TwelvePMCalc=[]
    OnePMCalc=[]
    TwoPMCalc=[]
    ThreePMCalc=[]
    FourPMCalc=[]
    FivePMCalc=[]
    SixPMCalc=[]
    SevenPMCalc=[]
    EightPMCalc=[]
    NinePMCalc=[]
    TenPMCalc=[]
    ElevenPMCalc=[]

    #create add day button with it's functions
    def AddDay():
        #Non local variables
        nonlocal i
        nonlocal SixAMCalc
        nonlocal SevenAMCalc
        nonlocal EightAMCalc
        nonlocal NineAMCalc
        nonlocal TenAMCalc
        nonlocal ElevenAMCalc
        nonlocal TwelvePMCalc
        nonlocal OnePMCalc
        nonlocal TwoPMCalc
        nonlocal ThreePMCalc
        nonlocal FourPMCalc
        nonlocal FivePMCalc
        nonlocal SixPMCalc
        nonlocal SevenPMCalc
        nonlocal EightPMCalc
        nonlocal NinePMCalc
        nonlocal TenPMCalc
        nonlocal ElevenPMCalc
        #add one per day
        i+=1

        #control for loop
        ctrl=1

        #total amount of products per hour
        SixAMTotal=0
        SevenAMTotal=0
        EightAMTotal=0
        NineAMTotal=0
        TenAMTotal=0
        ElevenAMTotal=0
        TwelvePMTotal=0
        OnePMTotal=0
        TwoPMTotal=0
        ThreePMTotal=0
        FourPMTotal=0
        FivePMTotal=0
        SixPMTotal=0
        SevenPMTotal=0
        EightPMTotal=0
        NinePMTotal=0
        TenPMTotal=0
        ElevenPMTotal=0
        
        for ctrl in range(0,i):
            #6 am
            SixAMCalc.append(int(float(SixAM.get())))
            SixAMTotal=SixAMTotal+SixAMCalc[ctrl]
            #7 am
            SevenAMCalc.append(int(float(SevenAM.get())))
            SevenAMTotal=SevenAMTotal+SevenAMCalc[ctrl]
            #8 am
            EightAMCalc.append(int(float(EightAM.get())))
            EightAMTotal=EightAMTotal+EightAMCalc[ctrl]
            #9 am
            NineAMCalc.append(int(float(NineAM.get())))
            NineAMTotal=NineAMTotal+NineAMCalc[ctrl]
            #10 am
            TenAMCalc.append(int(float(TenAM.get())))
            TenAMTotal=TenAMTotal+TenAMCalc[ctrl]
            #11 am
            ElevenAMCalc.append(int(float(ElevenAM.get())))
            ElevenAMTotal=ElevenAMTotal+ElevenAMCalc[ctrl]
            #12 pm
            TwelvePMCalc.append(int(float(TwelvePM.get())))
            TwelvePMTotal=TwelvePMTotal+TwelvePMCalc[ctrl]
            #1 pm
            OnePMCalc.append(int(float(OnePM.get())))
            OnePMTotal=OnePMTotal+OnePMCalc[ctrl]
            #2 pm
            TwoPMCalc.append(int(float(TwoPM.get())))
            TwoPMTotal=TwoPMTotal+TwoPMCalc[ctrl]
            #3 pm
            ThreePMCalc.append(int(float(ThreePM.get())))
            ThreePMTotal=ThreePMTotal+ThreePMCalc[ctrl]
            #4 pm
            FourPMCalc.append(int(float(FourPM.get())))
            FourPMTotal=FourPMTotal+FourPMCalc[ctrl]
            #5 pm
            FivePMCalc.append(int(float(FivePM.get())))
            FivePMTotal=FivePMTotal+FivePMCalc[ctrl]
            #6 pm
            SixPMCalc.append(int(float(SixPM.get())))
            SixPMTotal=SixPMTotal+SixPMCalc[ctrl]
            #7 pm
            SevenPMCalc.append(int(float(SevenPM.get())))
            SevenPMTotal=SevenPMTotal+SevenPMCalc[ctrl]
            #8 pm
            EightPMCalc.append(int(float(EightPM.get())))
            EightPMTotal=EightPMTotal+EightPMCalc[ctrl]
            #9 pm
            NinePMCalc.append(int(float(NinePM.get())))
            NinePMTotal=NinePMTotal+NinePMCalc[ctrl]
            #10 pm
            TenPMCalc.append(int(float(TenPM.get())))
            TenPMTotal=TenPMTotal+TenPMCalc[ctrl]
            #11 pm
            ElevenPMCalc.append(int(float(ElevenPM.get())))
            ElevenPMTotal=ElevenPMTotal+ElevenPMCalc[ctrl]
            ctrl=ctrl+1

        #Calculate averages for products by hour
        
        #Average products for six AM
        SixAMAverage=int(SixAMTotal/i)
        MakeSixAM.set(SixAMAverage)
        #Average products for seven AM
        SevenAMAverage=int(SevenAMTotal/i)
        MakeSevenAM.set(SevenAMAverage)
        #Average products for eight AM
        EightAMAverage=int(EightAMTotal/i)
        MakeEightAM.set(EightAMAverage)
        #Average products for nine AM
        NineAMAverage=int(NineAMTotal/i)
        MakeNineAM.set(NineAMAverage)
        #Average products for ten AM
        TenAMAverage=int(TenAMTotal/i)
        MakeTenAM.set(TenAMAverage)
        #Average products for eleven AM
        ElevenAMAverage=int(ElevenAMTotal/i)
        MakeElevenAM.set(ElevenAMAverage)
        #Average products for twelve PM
        TwelvePMAverage=int(TwelvePMTotal/i)
        MakeTwelvePM.set(TwelvePMAverage)
        #Average products for one PM
        OnePMAverage=int(OnePMTotal/i)
        MakeOnePM.set(OnePMAverage)
        #Average products for two PM
        TwoPMAverage=int(TwoPMTotal/i)
        MakeTwoPM.set(TwoPMAverage)
        #Average products for three PM
        ThreePMAverage=int(ThreePMTotal/i)
        MakeThreePM.set(ThreePMAverage)
        #Average products for four PM
        FourPMAverage=int(FourPMTotal/i)
        MakeFourPM.set(FourPMAverage)
        #Average products for five PM
        FivePMAverage=int(FivePMTotal/i)
        MakeFivePM.set(FivePMAverage)
        #Average products for six PM
        SixPMAverage=int(SixPMTotal/i)
        MakeSixPM.set(SixPMAverage)
        #Average products for seven PM
        SevenPMAverage=int(SevenPMTotal/i)
        MakeSevenPM.set(SevenPMAverage)
        #Average products for eight PM
        EightPMAverage=int(EightPMTotal/i)
        MakeEightPM.set(EightPMAverage)
        #Average products for nine PM
        NinePMAverage=int(NinePMTotal/i)
        MakeNinePM.set(NinePMAverage)
        #Average products for ten PM
        TenPMAverage=int(TenPMTotal/i)
        MakeTenPM.set(TenPMAverage)
        #Average products for eleven PM
        ElevenPMAverage=int(ElevenPMTotal/i)
        MakeElevenPM.set(ElevenPMAverage)
        
            
    
#Input totals sold

    #6AM
    Label(firstframe, text="6 AM:").grid(row=0)
    SixAM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    SixAM.grid(row=0, column=1)

    #7AM
    Label(firstframe, text="7 AM:").grid(row=1)
    SevenAM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    SevenAM.grid(row=1, column=1)

    #8AM
    Label(firstframe, text="8 AM:").grid(row=2)
    EightAM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    EightAM.grid(row=2, column=1)
    
    #9AM
    Label(firstframe, text="9 AM:").grid(row=3)
    NineAM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    NineAM.grid(row=3, column=1)

    #10AM
    Label(firstframe, text="10 AM:").grid(row=4)
    TenAM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    TenAM.grid(row=4, column=1)

    #11AM
    Label(firstframe, text="11 AM:").grid(row=5)
    ElevenAM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    ElevenAM.grid(row=5, column=1)

    #12PM
    Label(firstframe, text="12 PM:").grid(row=6)
    TwelvePM = Entry(firstframe,validate="key",validatecommand=(isvalid,"%S"))
    TwelvePM.grid(row=6, column=1)

    #1PM
    Label(firstframe, text="1 PM:").grid(row=7)
    OnePM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    OnePM.grid(row=7, column=1)

    #2PM
    Label(firstframe, text="2 PM:").grid(row=8)
    TwoPM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    TwoPM.grid(row=8, column=1)

    #3PM
    Label(firstframe, text="3 PM:").grid(row=9)
    ThreePM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    ThreePM.grid(row=9, column=1)

    #4PM
    Label(firstframe, text="4 PM:").grid(row=10)
    FourPM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    FourPM.grid(row=10, column=1)

    #5PM
    Label(firstframe, text="5 PM:").grid(row=11)
    FivePM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    FivePM.grid(row=11, column=1)

    #6PM
    Label(firstframe, text="6 PM:").grid(row=12)
    SixPM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    SixPM.grid(row=12, column=1)

    #7PM
    Label(firstframe, text="7 PM:").grid(row=13)
    SevenPM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    SevenPM.grid(row=13, column=1)

    #8PM
    Label(firstframe, text="8 PM:").grid(row=14)
    EightPM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    EightPM.grid(row=14, column=1)

    #9PM
    Label(firstframe, text="9 PM:").grid(row=15)
    NinePM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    NinePM.grid(row=15, column=1)

    #10PM
    Label(firstframe, text="10 PM:").grid(row=16)
    TenPM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    TenPM.grid(row=16, column=1)

    #11PM
    Label(firstframe, text="11 PM:").grid(row=17)
    ElevenPM = Entry(firstframe,validate="all",validatecommand=(isvalid,"%S"))
    ElevenPM.grid(row=17, column=1)

    #Display results

    #6 am results
    Label(firstframe, text='Amount to make at 6 AM:').grid(row=18)
    Label(firstframe,text="",textvariable=MakeSixAM).grid(row=18,column=1)
    #7 am results
    Label(firstframe, text='Amount to make at 7 AM:').grid(row=19)
    Label(firstframe,text="",textvariable=MakeSevenAM).grid(row=19,column=1)
    #8 am results
    Label(firstframe, text='Amount to make at 8 AM:').grid(row=20)
    Label(firstframe,text="",textvariable=MakeEightAM).grid(row=20,column=1)
    #9 am results
    Label(firstframe, text='Amount to make at 9 AM:').grid(row=21)
    Label(firstframe,text="",textvariable=MakeNineAM).grid(row=21,column=1)
    #10 am results
    Label(firstframe, text='Amount to make at 10 AM:').grid(row=22)
    Label(firstframe,text="",textvariable=MakeTenAM).grid(row=22,column=1)
    #11 am results
    Label(firstframe, text='Amount to make at 11 AM:').grid(row=23)
    Label(firstframe,text="",textvariable=MakeElevenAM).grid(row=23,column=1)
    #12 pm results
    Label(firstframe, text='Amount to make at 12 PM:').grid(row=24)
    Label(firstframe,text="",textvariable=MakeTwelvePM).grid(row=24,column=1)
    #1 pm results
    Label(firstframe, text='Amount to make at 1 PM:').grid(row=25)
    Label(firstframe,text="",textvariable=MakeOnePM).grid(row=25,column=1)
    #2pm results
    Label(firstframe, text='Amount to make at 2 PM:').grid(row=26)
    Label(firstframe,text="",textvariable=MakeTwoPM).grid(row=26,column=1)
    #3pm results
    Label(firstframe, text='Amount to make at 3 PM:').grid(row=27)
    Label(firstframe,text="",textvariable=MakeThreePM).grid(row=27,column=1)
    #4pm results
    Label(firstframe, text='Amount to make at 4 PM:').grid(row=28)
    Label(firstframe,text="",textvariable=MakeFourPM).grid(row=28,column=1)
    #5pm results
    Label(firstframe, text='Amount to make at 5 PM:').grid(row=29)
    Label(firstframe,text="",textvariable=MakeFivePM).grid(row=29,column=1)
    #6pm results
    Label(firstframe, text='Amount to make at 6 PM:').grid(row=30)
    Label(firstframe,text="",textvariable=MakeSixPM).grid(row=30,column=1)
    #7pm results
    Label(firstframe, text='Amount to make at 7 PM:').grid(row=31)
    Label(firstframe,text="",textvariable=MakeSevenPM).grid(row=31,column=1)
    #8pm results
    Label(firstframe, text='Amount to make at 8 PM:').grid(row=32)
    Label(firstframe,text="",textvariable=MakeEightPM).grid(row=32,column=1)
    #9pm results
    Label(firstframe, text='Amount to make at 9 PM:').grid(row=33)
    Label(firstframe,text="",textvariable=MakeNinePM).grid(row=33,column=1)
    #10pm results
    Label(firstframe, text='Amount to make at 10 PM:').grid(row=34)
    Label(firstframe,text="",textvariable=MakeTenPM).grid(row=34,column=1)
    #11pm results
    Label(firstframe, text='Amount to make at 11 PM:').grid(row=35)
    Label(firstframe,text="",textvariable=MakeElevenPM).grid(row=35,column=1)

    #button to add a day
    addday = Button(secondframe, text ='Add Day', command=AddDay)
    addday.pack()


    #Exit button
    exitbutton = Button(secondframe, text ='Exit window', fg ='red', command=TotalsCalculator.destroy)
    exitbutton.pack()

    #disable calculation button until all forms are filled
    addday.configure(state="disabled")
###############################
#    End Totals Calculator    #
###############################


#main buttons
btnProfitCalc=Button(root, text="Open profit calculator", command=OpenProfitCalculator).pack(pady=10)
btnMakeAmount=Button(root, text="Open totals calculator", command=OpenTotalsCalculator).pack(pady=10)

exitbutton = Button(root, text ='Exit program', fg ='red', command=root.destroy)
exitbutton.pack()
root.mainloop()
